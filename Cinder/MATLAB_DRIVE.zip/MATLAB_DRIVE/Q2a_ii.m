function y=Q2a_ii(n)
for i=1:1:n
    y(i)=round(rand(1,1)*(n-1))+1;
end
end