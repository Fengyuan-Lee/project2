n=12;
t_2 = log(B_1/P)/(n*(log(1+r/n)));

years = floor(t_2);
months = ceil((t_2-years)*12);