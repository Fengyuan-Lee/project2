r = 24;
v_p = 4/3*pi*r^3
v_s = r * r/2 * r/4
sqrt(v_s*8)


