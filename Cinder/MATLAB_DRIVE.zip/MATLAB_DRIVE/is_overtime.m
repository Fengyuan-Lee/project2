function is_overtime(hours)
hours = input('how many hours?: ')
if hours >= 40;
fprintf('Hey, you get overtime!')
end
end