function vec = vecout(inputnumber);
inputnumber = 4;
vec = inputnumber:inputnumber+5;
end