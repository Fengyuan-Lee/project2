function p = pickone(vec)

    r= randi([1,length(vec)],1);
    p = vec(r);

end

