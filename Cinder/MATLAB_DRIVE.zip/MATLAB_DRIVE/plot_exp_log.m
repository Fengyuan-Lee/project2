n = 70;
x = linspace(0, 3.5, n);
plot(x, exp(x));
hold;
plot(x, log(x));