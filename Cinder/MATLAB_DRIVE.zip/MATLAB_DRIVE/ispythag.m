function result = ispythag(a, b, c)
a = 3;
b = 4;
c = 5;
sum_of_squares = a^2 + b^2;

result = sum_of_squares == c^2;
end

