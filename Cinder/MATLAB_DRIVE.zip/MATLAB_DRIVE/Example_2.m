P = 5000;
t = 17;
r= 8.5/100; %0.085
n = 12;

B_1 = P*(1+r)^t;
format bank
disp(B_1)