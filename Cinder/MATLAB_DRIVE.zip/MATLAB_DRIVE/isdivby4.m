function out = isdivby4(inputargument)
inputargument = input('your inoutargument is:');
out = rem(inputargument,4) == 0;
end
