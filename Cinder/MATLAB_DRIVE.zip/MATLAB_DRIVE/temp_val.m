function val = temp_val(c);
F = 5/9. *c + 32;
K = c+ 273.15;
input = input('Enter the temp in degrees C:')
input = input('Do you want K or F?')
val = 'The temp in degrees F is:' ,F)
