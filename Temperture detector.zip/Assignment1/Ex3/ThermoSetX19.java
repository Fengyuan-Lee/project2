package itec3030.assignments.a1.sensors.thermoset.ThermoSetX19;

import itec3030.assignments.a1.sensors.thermoset.ThermoSetX19FrontEnd.FrontEnd;
import itec3030.smarthome.standards.ControllerInterface;
import itec3030.smarthome.standards.Thermostat;

public class ThermoSetX19 implements Thermostat {

    private FrontEnd frontEnd = new FrontEnd(this);


    private boolean enabled;
    private int temperature;

    private String id;

    private ControllerInterface controllerInterface;


    public ThermoSetX19() {
        this.frontEnd.setSize(600,200);
        this.frontEnd.setVisible(true);
    }

    @Override
    public void newTemperature(int i) {
        this.temperature = i;
    }

    @Override
    public ControllerInterface getController() {
        return controllerInterface;
    }

    @Override
    public void setController(ControllerInterface controllerInterface) {

    }

    @Override
    public String getID() {
        return this.id;
    }

    @Override
    public void setID(String s) {
        this.id = s;
    }

    @Override
    public void enable() {
        this.enabled = true;
    }

    @Override
    public void disable() {
        this.enabled = false;
    }

    @Override
    public boolean enabled() {
        return this.enabled;
    }

    @Override
    public int getReading() {
        return this.temperature;
    }
}
